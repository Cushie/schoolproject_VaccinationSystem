#include <iostream>
#include <string>
#include <fstream>
#include<cstdlib>
#include<conio.h>
#include<iomanip>

using namespace std;

const int num=10;

string Patient_Reg_no [num] = {};
string Patient_Full_Name [num] = {};
string Omang_PassportNo [num] = {};
string Location_ResidentAddress [num] = {};
string Workplace[num] = {};
string Work_Category [num] = {};
string Name_of_Vaccine [num] = {};
string Vaccination_Center [num] = {};
string Previous_Test_Status [num] = {};
string Test_Date [num] = {};

//use this to enter details of the patient
 void Add_Record()
 {

     {
         system ("CLS");
         cout << "Current Record(s)" << endl;
         cout << "**************************" << endl;



     }

     char PatRegNo[10];
     char PatName[50];
     char ID_PasNum[10];
     char Loc_ResAd [30];
     char W_Place[20];
     char Work_Cat[20];
     char Name_of_Vacc[20];
     char Vacc_Center[20];
      char Prev_Status[10];
      char Last_TestDate[10];

     cin.ignore();
    cout<<"PatRegNo.";
    cin.getline(PatRegNo,10);
    cout<<"PatName.";
    cin.getline(PatName,50);
    cout<<"ID_PasNum.";
    cin.getline(ID_PasNum,10);
    cout<<"Loc_ResAd.";
    cin.getline(Loc_ResAd,30);
    cout<<" W_Place.";
    cin.getline( W_Place,20);
    cout<<"Work_Cat.";
    cin.getline(Work_Cat,20);
    cout<<"Name_of_Vacc.";
    cin.getline(Name_of_Vacc,20);
    cout<<"Vacc_Center.";
    cin.getline(Vacc_Center,20);
    cout<<" Prev_Status.";
    cin.getline(Prev_Status,10);
    cout<<"Last_TestDate.";
    cin.getline(Last_TestDate,10);



    for(int a=0;a<num;a++)
    {
        if (Omang_PassportNo[a]=="\0")
        {
            Patient_Reg_no[a]=   PatRegNo;
            Patient_Full_Name [a]=PatName;
            Omang_PassportNo[a]=ID_PasNum;
            Location_ResidentAddress[a]=Loc_ResAd;
            Workplace[a]=W_Place;
            Work_Category[a]=Work_Cat;
            Name_of_Vaccine[a]=Name_of_Vacc;
           Vaccination_Center[a]=Vacc_Center;
            Previous_Test_Status[a]=Prev_Status;
            Test_Date[a]=Last_TestDate;

            break;

        }

    }


 }


 void View_Record() //use this to show the details of the patient
 {
    system("CLS");
cout <<"Unsorted Records(s)"<<endl;
cout <<"******************"<<endl;

int counter=0;

cout <<"NO \n";
cout <<"Patient_Reg_no\n";
cout << "Patient_Full_Name\n";
cout <<"Omang_PassportNo\n";
cout << "Location_Residential address\n";
cout << "Workplace\n";
cout << "Work_category\n";
cout << "Name_Of_Vaccine\n";
cout << "Vaccination_Center\n";
cout << "Previous_Test_Status\n";
cout << "Last_Test_Date\n";


for (int a=0;a<num;a++)
    {
    if (Omang_PassportNo[a]!="\0")
    {
        counter++;
        cout<<"  "<<counter<<"    "<<Patient_Reg_no[a]<<"      "<<Patient_Full_Name[a]<<"      "<<Omang_PassportNo[a]<<"    "<<Location_ResidentAddress[a]<<"        "<<Workplace[a]<<"      "<<Work_Category[a]<<"        " <<Name_of_Vaccine[a]<<"       " <<Vaccination_Center[a]<<"       "<<Previous_Test_Status[a]<<"      "<<Test_Date[a]<<endl;

    }
}
}

//use this to search the specific patient through their Omang/Passport number
void Search_Record (string search){


    system ("CLS");
    cout <<"Unsorted record(s)"<<endl;
    cout <<"Search by Omang_PassportNo"<<endl;
    cout <<"##################"<<endl;

     int counter=0;

cout <<"NO \n";
cout << "Patient_Reg_no";
cout <<" Patient_Full_Name \n";
cout <<"Omang_PassportNo\n";
cout << "Location_Residential address\n";
cout << "Workplace\n";
cout << "Work_category\n";
cout << "Name_Of_Vaccine\n";
cout << "Vaccination_Center\n";
cout << "Previous_Test_Status\n";
cout << "Last_Test_Date\n";

    for (int a=0;a<num;a++)
        {

        if (Omang_PassportNo[a]==search)
            {
            counter ++;
             cout<<"  "<<counter<<"    "<< Patient_Reg_no[a]<<"      "<<Patient_Full_Name[a]<<"      "<<Omang_PassportNo[a]<<"    "<<Location_ResidentAddress[a]<<"        "<<Workplace[a]<<"      "<<Work_Category[a]<<"        " <<Name_of_Vaccine[a]<<"       " <<Vaccination_Center[a]<<"       "<<Previous_Test_Status[a]<<"      "<<Test_Date[a]<<endl;

    break;
        }
    }
         if (counter==0)
    {
        cout<<"Not found"<<endl;
    }
    cout <<"********************"<<endl;
}

void OpenFile() //use this to open file in append mode or write mode
{
string line;
 ifstream myfile("Vaccination.txt",ios::in);
if (myfile.is_open()){

int a=0;
    while(getline(myfile,line)){

       Patient_Reg_no[a]=line.substr();
       Patient_Full_Name[a]=line.substr();
        Omang_PassportNo[a]=line.substr();
       Location_ResidentAddress [a]=line.substr();
        Workplace[a]=line.substr();
       Work_Category[a]=line.substr();
        Name_of_Vaccine[a]=line.substr();
        Vaccination_Center[a]=line.substr();
         Previous_Test_Status [a]=line.substr();
        Test_Date[a]=line.substr();
        a++;


    }
}
else{
    cout <<"OPEN FILE!"<<endl;
}
}

void SaveToFile(){
ofstream myfile;
myfile.open("Vaccination.txt",ios::out);

for (int a=0;a<num;a++){
    if (Omang_PassportNo[a]=="\0"){
        break;
    }
    else{
        myfile<<Patient_Reg_no [a ]+","+Patient_Full_Name  [a] + ","+  Omang_PassportNo[a] +","+  Location_ResidentAddress[a] + "," +Workplace[a] + "," + Work_Category[a] + "," + Name_of_Vaccine[a] + "," + Vaccination_Center[a] + "," + Previous_Test_Status[a] + "," <<Test_Date [a]<<endl;
    }
}
}

/*This the main function where all the subclasses will be called and primarily the main execution  */

int main()
{
    std :: cout << "**********************************************************************\n";
    std :: cout << "****                      MINISTRY OF HEALTH AND WELLNESS                                       ********\n";
    std :: cout << "****                     DEPARTMENT OF HEALTH AND SAFETY                                       ********\n";
    std :: cout << "****                           GREATER GABORONE REGION                                               ********\n";
    std :: cout << "**********************************************************************\n";

    system("pause");
    system ("CLS");

      int option;
      string Omang_PassportNo;
      fstream my_file;

    do
    {
        //this is where the user will be able to choose the option they want

        cout << "**********COVID-19 VACCINATION SYSTEM***********"<<endl;
        cout << "*******Select Any Of The Options Below********" <<endl;
        cout << "1. Add_Record" << endl;
        cout << "2. View_Unsorted_Records" << endl;
        cout << "3. Sort Records in Ascending Order" << endl;
        cout << "4. Search_Record" << endl;
        cout << "5. Exit and Save " << endl;
        cout << "============================" << endl;

         cout << "Select  An option:" << endl;
         cin >> option;
         system ("CLS");

             switch (option)
             {
                 case 1:  Add_Record();
                 system ("CLS");
                 break;


                 case 2:View_Record();
                  break;

        case 4:
        system("CLS");
        cout <<"Omang_PassportNo"<<endl;
        cin>>Omang_PassportNo;
       getline(cin,Omang_PassportNo);
       Search_Record (Omang_PassportNo);
       break;
             }

    }while (option!=5);
  SaveToFile();
  cout <<"EXIT...SAVE!"<< endl;
    return 0;
}



